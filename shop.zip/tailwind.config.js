module.exports = {
  darkMode: 'media',
  variants: {
    extend: {
      textOpacity: ['dark'],
      padding: ['hover'],
    },
  },
};
