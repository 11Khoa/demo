<template>
  <div class="computer">
    <h1>computer</h1>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
