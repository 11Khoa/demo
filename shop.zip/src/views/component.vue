<template>
  <div class="component">
    <h1>component</h1>
  </div>
</template>

<script>
export default {
  name: 'ComponentPage',
};
</script>

<style></style>
