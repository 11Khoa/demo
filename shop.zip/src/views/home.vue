<template>
  <div class="main">
    <div id="key" class="swiper-container">
      <swiper
        v-if="keys.length > 1"
        ref="mySwiper"
        class="swiper-wrapper"
        :options="swiperOptions"
      >
        <swiper-slide
          v-for="(item, index) in keys"
          :key="index"
          class="swiper-slide"
        >
          <img :src="item.urlBanner" :alt="item.alt" />
        </swiper-slide>
        <div slot="pagination" class="swiper-pagination" />
      </swiper>
    </div>
    <div id="sec1">
      <div class="container">
        <div
          class="item border-hover"
          v-for="(cover, index) in covers"
          :key="index.id"
          :class="`item${index + 1}`"
        >
          <a href="#" class="bn1"
            ><img :src="cover.image" :alt="cover.title" />
            <div class="description">
              <div class="title">{{ cover.title }}</div>
              <div class="subtitle">{{ cover.subtitle }}</div>
              <div class="action1">
                <div class="banner_text">{{ cover.banner_text }}</div>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
    <div id="sec2">
      <div class="container">
        <h2 class="ttlh2">Weekly Deal Product</h2>
      </div>
      <div class="container flex flex-wrap justify-between">
        <Product
          class="mb-8"
          v-for="(product, index) in products"
          :key="index.id"
          :imgUrl="product.thumbnailUrl"
          :categoryID="product.categoryID"
          :color="product.color"
          :createAt="product.createAt"
          :updateAt="product.updateAt"
          :datesale="product.datesale"
          :description="product.description"
          :name="product.name"
          :price="product.price"
          :rating="product.rating"
          :idproduct="product.id"
        ></Product>
      </div>
    </div>
    <div
      id="sec3"
      :style="`background: url(${parralax.image}) no-repeat center center/cover;background-attachment: fixed;`"
    >
      <div class="container">
        <h2 class="ttlh2">Shop by category</h2>
        <swiper
          v-if="keys.length > 1"
          ref="mySwiper1"
          class="swiper-wrapper"
          :options="swiperOptions1"
        >
          <swiper-slide
            v-for="(item, index) in slider1"
            :key="index"
            class="swiper-slide"
            data-text="dummy"
          >
            <img :src="item.image" :alt="item.id" />
          </swiper-slide>
          <div class="swiper-button-prev" slot="button-prev"></div>
          <div class="swiper-button-next" slot="button-next"></div>
        </swiper>
      </div>
    </div>
    <div id="sec4">
      <div class="container">
        <Tabs
          v-bind="{
            dark,
          }"
        >
          <TabItem>
            <template #name>tab1</template>
            <div class="tab-content flex justify-between">
              <Product
                class="mb-8"
                v-for="(product, index) in products"
                :key="index.id"
                :imgUrl="product.thumbnailUrl"
                :categoryID="product.categoryID"
                :color="product.color"
                :createAt="product.createAt"
                :updateAt="product.updateAt"
                :datesale="product.datesale"
                :description="product.description"
                :name="product.name"
                :price="product.price"
                :rating="product.rating"
                :idproduct="product.id"
              ></Product>
            </div>
          </TabItem>
          <TabItem>
            <template #name>
              <span>tab2</span>
            </template>
            <div class="tab-content flex justify-between">
              <Product
                class="mb-8"
                v-for="(product, index) in products"
                :key="index.id"
                :imgUrl="product.thumbnailUrl"
                :categoryID="product.categoryID"
                :color="product.color"
                :createAt="product.createAt"
                :updateAt="product.updateAt"
                :datesale="product.datesale"
                :description="product.description"
                :name="product.name"
                :price="product.price"
                :rating="product.rating"
                :idproduct="product.id"
              ></Product>
            </div>
          </TabItem>
        </Tabs>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import Product from '../components/Product.vue';

export default {
  name: 'Home',
  components: {
    Product,
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.$swiper;
    },
  },
  data() {
    return {
      tablink: [
        { id: 1, text: 'tab1' },
        { id: 2, text: 'tab2' },
        { id: 3, text: 'tab3' },
      ],
      tabcontent: [
        { id: 1, text: 'content1' },
        { id: 2, text: 'content2' },
        { id: 3, text: 'content3' },
      ],
      parralax: {
        id: 1,
        image: require('@/assets/images/parralax.jpg'),
      },
      slider1: [
        { id: 1, image: require('@/assets/images/Cat-1.jpg') },
        { id: 2, image: require('@/assets/images/Cat-2.jpg') },
        { id: 3, image: require('@/assets/images/Cat-3.jpg') },
        { id: 4, image: require('@/assets/images/Cat-4.jpg') },
        { id: 5, image: require('@/assets/images/Cat-5.jpg') },
        { id: 6, image: require('@/assets/images/Cat-6.jpg') },
      ],
      covers: [
        {
          id: 1,
          image: require('@/assets/images/banner1.jpg'),
          title: 'Hot Gadgets',
          subtitle: 'Electronics Sale 20% Off',
          banner_text: 'Shop Now',
        },
        {
          id: 2,
          image: require('@/assets/images/banner2.jpg'),
          title: 'Best Sale Deal',
          subtitle: 'New iWatch Series - 5 20% Off',
          banner_text: 'Shop Now',
        },
        {
          id: 3,
          image: require('@/assets/images/banner3.jpg'),
          title: 'Hot Mobiles',
          subtitle: 'iphone Festival Sale 20% Off',
          banner_text: 'Shop Now',
        },
        {
          id: 4,
          image: require('@/assets/images/banner4.jpg'),
          title: '4K Television',
          subtitle: 'Smart Tv &amp; Television 4K HD LED',
          banner_text: 'Shop Now',
        },
      ],
      products: [],
      keys: [],
      swiperOptions: {
        effect: 'fade', //flip, fade, coverflow,cube
        fadeEffect: { crossFade: true },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        autoplay: {
          delay: 4000,
          stopOnLastSlide: false,
          disableOnInteraction: false,
        },
        grabCursor: false, //cursor: pointer
        speed: 1000,
        loop: true,
      },
      swiperOptions1: {
        slideToClickedSlide: true,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
        breakpoints: {
          1024: {
            slidesPerView: 7,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 5,
            spaceBetween: 30,
          },
          420: {
            slidesPerView: 4,
            spaceBetween: 20,
          },
          320: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
        autoplay: {
          delay: 4000,
          stopOnLastSlide: false,
          disableOnInteraction: false,
        },
        grabCursor: false, //cursor: pointer
        speed: 1000,
        loop: true,
      },
    };
  },
  async mounted() {
    const urlProducts = '/products?_page=1&_limit=5';
    const urlbanner = '/banners';

    const [
      {
        data: { data: product },
      },
      { data: banners },
    ] = await Promise.all([
      this.$http.get(urlProducts),
      this.$http.get(urlbanner),
    ]);
    this.products = product;
    this.keys = banners;
  },
};
</script>
<style lang="scss" scoped>
#key.swiper-container {
  margin-top: -30px;
  position: relative;
  z-index: 1;
}
.ttlh2 {
  text-transform: capitalize;
  font-size: 24px;
  font-weight: 400;
  margin-bottom: 40px;
  padding-bottom: 20px;
  background: linear-gradient(#da2127, #da2127) no-repeat center bottom/ 100px
    3px;
}
#sec2 {
  margin-top: 50px;
  padding-bottom: 30px;
}
#sec3 {
  padding: 100px 0;
  .ttlh2 {
    color: #fff;
  }
  .swiper-slide {
    position: relative;
    &::before {
      content: attr(data-text);
      position: absolute;
      bottom: 10px;
      left: 0;
      right: 0;
      text-align: center;
      text-transform: capitalize;
    }
  }
}
@import '@/assets/scss/_style.scss';
</style>
