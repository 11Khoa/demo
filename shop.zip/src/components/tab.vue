<template>
  <div class="tabs-switch">
    <div class="tab-link">
      <div
        class="item"
        v-for="(tab, index) in tablink"
        :key="index"
        :data-id="tab.id"
        @click="isActive = !isActive"
        :class="{ active: isActive }"
      >
        {{ tab.text }}
      </div>
    </div>
    <div class="tab-content">
      <div
        class="item1"
        v-for="(tabc, index) in tabcontent"
        :key="index"
        :data-id="tabc.id"
      >
        {{ tabc.text }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tab-switch',
  data() {
    return {
      isActive: true,
    };
  },
  props: ['tablink', 'tabcontent'],
};
</script>

<style lang="scss">
.tabs-switch {
  .tab-link {
    display: flex;
    justify-content: center;
    > * {
      padding: 0 10px;
      display: block;
      background-color: #ddd;
      cursor: pointer;
    }
  }
}
</style>
