<template>
  <footer>
    <div class="container">
      <div class="row1 box-subscribe">
        <ul class="mail-box">
          <li>
            <unicon name="megaphone" fill="currentColor" />SUBSCRIBE FOR JOIN
            US!
          </li>
          <li>
            <input
              type="email"
              name="email"
              required
              pattern="[A-Za-z]+"
            /><button type="submit">subscribe</button>
          </li>
        </ul>
        <ul class="social">
          <li>
            <a href="#"><unicon name="facebook-f" fill="currentColor" /></a>
          </li>
          <li>
            <a href="#"><unicon name="twitter" fill="currentColor" /></a>
          </li>
          <li>
            <a href="#"><unicon name="google" fill="currentColor" /></a>
          </li>
          <li>
            <a href="#"><unicon name="instagram" fill="currentColor" /></a>
          </li>
          <li>
            <a href="#"><unicon name="youtube" fill="currentColor" /></a>
          </li>
          <li>
            <a href="#"><unicon name="rss" fill="currentColor" /></a>
          </li>
          <li>
            <a href="#"><unicon name="skype" fill="currentColor" /></a>
          </li>
        </ul>
      </div>
      <div class="row2 info">
        <h3>Contact Information</h3>
        <ul>
          <li class="txt-call">Call Us 24/7 Free</li>
          <li class="txt-tel">
            <a href="tel:0703102705">0123456789</a>
          </li>
          <li class="txt-address">
            60, 29th Street, San Francisco, CA 94110, United States
          </li>
          <li class="app-mobile">
            <a href="#"><img src="@/assets/images/play.png" alt="chplay" /></a>
            <a href="#"
              ><img src="@/assets/images/store.png" alt="appstore"
            /></a>
          </li>
        </ul>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'CompFooter',
  data() {
    return {};
  },
};
</script>

<style></style>
