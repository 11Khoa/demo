import Vue from 'vue';
import VueRouter from 'vue-router';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    component: () => import('../layout/main.vue'),
    children: [
      {
        path: '/',
        name: 'home',
        component: () => import('../views/home.vue'),
        meta: {
          pageTitle: 'home',
        },
      },
      {
        path: '/television',
        name: 'television',
        // route level code-splitting
        // this generates a separate chunk (television.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () =>
          import(
            /* webpackChunkName: "television" */ '../views/television.vue'
          ),
      },
      {
        path: '/component',
        name: 'component',
        component: () => import('../views/component.vue'),
      },
      {
        path: '/computer',
        name: 'computer',
        component: () => import('../views/computer.vue'),
      },
      // {
      //   path: '/:catchAll(.*)',
      //   conponent: NotFoundComponent,
      //   name: 'Page Not Found',
      // }
    ],
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
